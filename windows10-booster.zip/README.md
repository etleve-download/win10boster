# ⚡ Windows 10 Booster

A lightweight `.bat` script to boost Windows 10 performance on Intel and AMD CPUs. Ideal for gaming, productivity, and general speed-up.

## 🚀 Features

- Detects CPU (Intel or AMD)
- Disables Core Parking
- Enables Ultimate Performance Power Plan
- Disables unnecessary services (e.g., Xbox, telemetry)
- Optimizes UI responsiveness
- Clears temporary files

## 🖥️ Supported OS

- Windows 10 Home
- Windows 10 Pro
- Compatible with Intel & AMD CPUs

## 📦 Installation

1. Download the latest version from the [Releases](https://github.com/yourname/windows10-booster/releases).
2. Right-click `booster.bat` → **Run as administrator**
3. Follow the on-screen instructions

## 🔁 Restore

If you'd like to undo changes, you can use the optional `restore.bat` script.

## 📄 License

[MIT](LICENSE)
